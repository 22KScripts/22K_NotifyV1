fx_version 'cerulean'
game 'gta5'

lua54 'yes'

escrow_ignore {
    'config.lua'
}

author '22K Scripts'
description 'Notify System'
version '1.0.0'

client_script 'client.lua'
shared_script 'config.lua'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

dependency '/assetpacks'