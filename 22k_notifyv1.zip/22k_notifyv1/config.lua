Config = {}

Config.Language = 'en' -- hu / en
Config.NotifyDuration = 5000 -- time in ms ( 5000 = 5 mp)

Config.Texts = {
    ['hu'] = {
        title = "Értesítés"
    },
    ['en'] = {
        title = "Notification"
    }
}
